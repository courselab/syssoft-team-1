/*
 *    SPDX-FileCopyrightText: 2021 Monaco F. J. <monaco@usp.br>
 *    SPDX-FileCopyrightText: 2025 FelipeTanusR <fetanus@usp.br>
 *   
 *    SPDX-License-Identifier: GPL-3.0-or-later
 *
 *  This file is a derivative of SYSeg (https://gitlab.com/monaco/syseg)
 *  and includes modifications made by the following author(s):
 *  FelipeTanusR <fetanus@usp.br>
 */

#include <stdio.h>

int main()
{
  printf ("Main's ddress: %p\n", main);
  
  return 0;
}
